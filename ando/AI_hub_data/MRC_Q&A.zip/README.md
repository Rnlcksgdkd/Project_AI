# MRC Q&A

## Task
```
주어진 장문의 글 내용을 파악하여 제시한 질문에 답변 찾기

모델 파라미터 수는 100,000,000 (100M)으로 제한됩니다.
```

## Dataset
### 본문의 수
| Phase | # |
| - | - |
| train | 33,119 |
| validate | 7097 |
| test | 7098 |


### 질문&답변 수
| Phase | # |
| - | - |
| train | 170,609 |
| validate | 36,368 |
| test | 36,448 |


## Data Directory
```
\_data
    \_ train.json
    \_ validate.json
    \_ test.json
    \_ vocab.json
```


## Data Sample
```
{
    "title": "649",
    "paragraphs": [
        {
            "context": "[OSEN=강서정 기자] 걸그룹 우주소녀의 성소가 ‘설특집 2018 아이돌 육상·볼링·양궁·리듬체조·에어로빅 선수권 대회’(이하 아육대) 출연 소감을 전했다.성소는 15일 우주소녀 공식 인스타그램에 “먼저 설날 여러분 새해 복 많이 받으세요~ 이번 설날 ‘아육대’에서 오랜만에 리듬체조도 하게 되었는데 저한테 기대 많이 했는데 이번에 좀 실망을 드린 것 같아요. 그래도 이번에 즐기면서 재밌게 했어요. 너무 좋은 추억이 되었어요!”라는 글을 게재했다.이어 “항상 하면서 좋은 언니, 동생, 친구 만날 수 있고 선생님도 뵐 수 있었고! 저와 2년 동안 함께 고생하셨던 선생님 그리고 이번에 함께 하셨던 선수 분들 고생 많았어요! 너무 축하하고 모두모두 설날 해피!! 우리 팬분들도 걱정 많이 하셨는데 너무 걱정 안해도 돼요 이제. 우정 너무 고마워요”라고 고마운 마음을 전했다.성소는 이날 방송된 MBC ‘아육대’ 리듬체조 경기에 출전했다. 원조 ‘리듬체조 여신’ 성소가 이번에도 기대를 모았는데 발레경력 7년의 에이프릴의 레이첼이 완벽한 경기를 선보이며 성소를 제치고 우승했다. /kangsj@osen.co.kr[사진] 우주소녀 인스타그램",
            "qas": [
                {
                    "question": "걸그룹 우주소녀의 성소가 이 프로그램에 출연해 리듬체조 경기에 출전했는데, 이 프로그램의 이름은?",
                    "answers": [
                        {
                            "answer_start": 450,
                            "text": "아육대"
                        }
                    ],
                    "id": "m5_306497-1",
                    "classtype": "work_who"
                }
            ]
        }
    ],
    "source": 6
}

제목(title), 본문의 카테고리(source), 본문(context), 질문 번호(id), 육하원칙(classtype)
질문(question), 정답의 시작위치(answer_start), 정답(text)
```


## Metric
```
필독 부탁드립니다!

기존 Word Error Rate 평가 방식에 문제점이 발견되어, 부득이하게 음절 단위의 f1 score를 이용한 평가로 변경하게 되었습니다.

KorQuAD 2.0 evaluation script와 동일한 방식으로 평가되며, 평가에 대한 자세한 방법은 evaluation.py를 참고해 주시기 바랍니다.

https://korquad.github.io/
```


## Description
```
data 폴더의 vocab.json은 train.json의 본문들을 scikit-learn 라이브러리의 CountVectorizer를 이용하여 제작한 vocabulary입니다. 

vocab.json 을 사용하지 않고 직접 만드셔도 됩니다.

Baseline 코드에서는 본문과 질문을 vocab.json을 이용해 길이 128의 sequence로 만들어 모델의 input으로 사용합니다.

Baseline 모델은 Linear Layer 하나로 구성되어 있으며, 결과는 2개의 output(본문에서 answer의 start index와 end index)로 출력됩니다.

prediction.json의 포맷은 Baseline 코드를 실행시키시면 확인하실 수 있습니다.

Baseline에서 제공되는 코드는 MRC를 위한 간단한 흐름만이 구현되어 있기 때문에, 제대로 동작할 수 있도록 코드를 수정하셔야 합니다.
```


## Commands
```
# train
python main.py --lr=0.001 --cuda=True --num_epochs=10 --print_iter=10 --prediction_file="prediction.json" --batch=4 --mode="train"

# test (for submission)
python main.py --batch=4 --model_name="1.pth" --prediction_file="prediction.json" --mode="test" 


예시 커맨드에 있는 값은 모두 기본값입니다.
```


## Submission
```
prediction.json을 제출하시면 됩니다.

prediction.json은 {"id": "answer_string", "id": "answer_string", ...} 형태입니다.
```

## Materials
```
Baseline 코드에 기본적인 모델도 들어가 있지 않기 때문에, 참고할 만한 자료들의 링크를 제공합니다.


BERT

https://github.com/google-research/bert


Ai NLP Challenge

https://challenge.enliple.com/

https://github.com/enlipleai/kor_pretrain_LM


HanBert

https://twoblockai.com/2020/01/22/hanbert%EB%A5%BC-%EA%B3%B5%EA%B0%9C%ED%95%A9%EB%8B%88%EB%8B%A4/


Pytorch Transformers

https://pytorch.org/hub/huggingface_pytorch-transformers/

https://github.com/huggingface/transformers
```


```
!!!!!!!!!!!!!!!!!!!!! 필독!!!!!!!!!!!!!!!!!!!!!!!!!!!
** 컨테이너 내 기본 제공 폴더
- /datasets : read only 폴더 (각 태스크를 위한 데이터셋 제공)
- /tf/notebooks :  read/write 폴더 (참가자가 Wirte 용도로 사용할 폴더)
1. 참가자는 /datasets 폴더에 주어진 데이터셋을 적절한 폴더(/tf/notebooks) 내에 복사/압축해제 등을 진행한 뒤 사용해야합니다.
   예시> Jpyter Notebook 환경에서 압축 해제 예시 : !bash -c "unzip /datasets/objstrgzip/18_NLP_comments.zip -d /tf/notebooks/
   예시> Terminal(Vs Code) 환경에서 압축 해제 예시 : bash -c "unzip /datasets/objstrgzip/18_NLP_comments.zip -d /tf/notebooks/
   
2. 참가자는 각 문제별로 데이터를 로드하기 위해 적절한 path를 코드에 입력해야합니다. (main.py 참조)
3. 참가자는 모델의 결과 파일(Ex> prediction.txt)을 write가 가능한 폴더에 저장되도록 적절 한 path를 입력해야합니다. (main.py 참조)
4. 세션/컨테이너 등 재시작시 위에 명시된 폴더(datasets, notebooks) 외에는 삭제될 수 있으니 
   참가자는 적절한 폴더에 Dataset, Source code, 결과 파일 등을 저장한 뒤 활용해야합니다.
   
!!!!!!!!!!!!!!!!!!!!! 필독!!!!!!!!!!!!!!!!!!!!!!!!!!!
```
